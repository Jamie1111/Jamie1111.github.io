/******************************************************************************
 * Programming Basics Exam - Car Category
 * ----------------------------------------------------------------------------
 * Instructions:
 * - This is the starter code for your exam project.
 * - You are required to complete the tasks as per the exam guidelines and 
 *   instructions provided.
 * 
 * Good luck!
 ******************************************************************************/
// This loads the current prices. It calls `fetchData()` from the rates.js file
// to mimic the fetching of remote data.
const currentPrices = fetchData();

window.addEventListener('load', onPageLoad);

/**
 * Called when on the load event (when the DOM is ready).
 */
function onPageLoad() {
  //TODO replace this TODO with code to initialize the application

}

// TODO replace this TODO with your own functions and other code
